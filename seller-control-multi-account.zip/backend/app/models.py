from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy import String, Integer, DateTime, Text, ForeignKey, Boolean, Numeric, JSON
from datetime import datetime
from .db import Base

class SellerAccount(Base):
    __tablename__ = "seller_accounts"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    region: Mapped[str] = mapped_column(String(10), default="eu")
    marketplaces: Mapped[str] = mapped_column(String(200), default="DE,FR,IT,ES")
    refresh_token: Mapped[str] = mapped_column(Text, nullable=False)

    # Optional overrides (else use env defaults)
    lwa_client_id: Mapped[str | None] = mapped_column(String(200), nullable=True)
    lwa_client_secret: Mapped[str | None] = mapped_column(String(200), nullable=True)
    aws_access_key: Mapped[str | None] = mapped_column(String(200), nullable=True)
    aws_secret_key: Mapped[str | None] = mapped_column(String(200), nullable=True)
    role_arn: Mapped[str | None] = mapped_column(String(300), nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    order_id: Mapped[str] = mapped_column(String(40), index=True)
    purchase_date: Mapped[datetime | None]
    status: Mapped[str | None] = mapped_column(String(40))
    marketplace: Mapped[str | None] = mapped_column(String(10))
    data: Mapped[dict | None] = mapped_column(JSON)

class OrderItem(Base):
    __tablename__ = "order_items"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    order_id: Mapped[str] = mapped_column(String(40), index=True)
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    qty: Mapped[int | None] = mapped_column(Integer)
    price_amount: Mapped[float | None] = mapped_column(Numeric(12,2))
    currency: Mapped[str | None] = mapped_column(String(3))

class ReturnFBA(Base):
    __tablename__ = "returns_fba"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    return_date: Mapped[datetime | None] = mapped_column(DateTime)
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    disposition: Mapped[str | None] = mapped_column(String(30))
    reason: Mapped[str | None] = mapped_column(String(200))
    fc: Mapped[str | None] = mapped_column(String(20))
    qty: Mapped[int | None] = mapped_column(Integer)

class ReturnFBM(Base):
    __tablename__ = "returns_fbm"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    return_date: Mapped[datetime | None] = mapped_column(DateTime)
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    reason: Mapped[str | None] = mapped_column(String(200))
    qty: Mapped[int | None] = mapped_column(Integer)

class RemovalOrder(Base):
    __tablename__ = "removals_orders"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    removal_order_id: Mapped[str | None] = mapped_column(String(50), index=True)
    order_type: Mapped[str | None] = mapped_column(String(20))  # Return/Disposal
    status: Mapped[str | None] = mapped_column(String(30))
    created_at: Mapped[datetime | None] = mapped_column(DateTime)

class RemovalShipment(Base):
    __tablename__ = "removals_shipments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    removal_order_id: Mapped[str | None] = mapped_column(String(50), index=True)
    tracking: Mapped[str | None] = mapped_column(String(60))
    qty: Mapped[int | None] = mapped_column(Integer)
    received_date: Mapped[datetime | None] = mapped_column(DateTime)

class InventoryLedger(Base):
    __tablename__ = "inventory_ledger"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    event_date: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    event_type: Mapped[str | None] = mapped_column(String(40))  # Lost/Damaged/Found/Adjustment
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    fc: Mapped[str | None] = mapped_column(String(20))
    qty: Mapped[int | None] = mapped_column(Integer)
    reference: Mapped[str | None] = mapped_column(String(80))

class Reimbursement(Base):
    __tablename__ = "reimbursements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    posted_date: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    case_id: Mapped[str | None] = mapped_column(String(60))
    reason: Mapped[str | None] = mapped_column(String(200))
    units: Mapped[int | None] = mapped_column(Integer)
    amount: Mapped[float | None] = mapped_column(Numeric(12,2))

class ReconResult(Base):
    __tablename__ = "recon_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("seller_accounts.id"), index=True)
    asin: Mapped[str | None] = mapped_column(String(20), index=True)
    sku: Mapped[str | None] = mapped_column(String(80), index=True)
    window_from: Mapped[datetime | None] = mapped_column(DateTime)
    window_to: Mapped[datetime | None] = mapped_column(DateTime)
    lost_units: Mapped[int | None] = mapped_column(Integer, default=0)
    damaged_units: Mapped[int | None] = mapped_column(Integer, default=0)
    found_units: Mapped[int | None] = mapped_column(Integer, default=0)
    reimbursed_units: Mapped[int | None] = mapped_column(Integer, default=0)
    reimbursed_amount: Mapped[float | None] = mapped_column(Numeric(12,2), default=0)
    open_units: Mapped[int | None] = mapped_column(Integer, default=0)
    open_amount: Mapped[float | None] = mapped_column(Numeric(12,2), default=0)
