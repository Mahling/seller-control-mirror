# Minimal SP-API wrapper (stubs). Replace with real calls.
# Example library: python-amazon-sp-api (Orders, Reports).
from typing import List, Dict, Any
from datetime import datetime, timedelta

def pull_orders_stub(account_cfg: dict, date_from: datetime, date_to: datetime) -> list[dict]:
    # TODO: replace with real Orders API calls
    return [
        {
            "orderId": "TEST-ORDER-1",
            "purchaseDate": date_from.isoformat(),
            "status": "Shipped",
            "marketplace": "DE",
            "items": [{"asin": "B00TEST123", "sku": "SKU-1", "qty": 1, "price": 19.99, "currency": "EUR"}],
        }
    ]

def fetch_reports_and_upsert_stub(account_cfg: dict) -> dict:
    # TODO: replace with real Reports API calls for returns/removals/ledger/reimbursements
    # Return counts for UI badges
    return {"returns": 0, "removals": 0, "ledger": 0, "reimbursements": 0}
