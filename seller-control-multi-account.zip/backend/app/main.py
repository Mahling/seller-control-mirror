from fastapi import FastAPI, Depends, HTTPException, Form, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from .db import Base, engine, get_db
from . import models, schemas
from .settings import settings
from .sp_api import pull_orders_stub, fetch_reports_and_upsert_stub
from .services import reconcile_account

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Seller-Control (Multi-Account)")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def dashboard(request: Request, db: Session = Depends(get_db)):
    accounts = db.query(models.SellerAccount).all()
    return templates.TemplateResponse("index.html", {"request": request, "accounts": accounts})

@app.get("/api/accounts")
def list_accounts(db: Session = Depends(get_db)):
    rows = db.query(models.SellerAccount).all()
    return [schemas.SellerAccountOut.model_validate(r).model_dump() for r in rows]

@app.post("/api/accounts", response_model=schemas.SellerAccountOut)
def add_account(payload: schemas.SellerAccountIn, db: Session = Depends(get_db)):
    acc = models.SellerAccount(**payload.model_dump())
    db.add(acc)
    db.commit()
    db.refresh(acc)
    return schemas.SellerAccountOut.model_validate(acc)

@app.post("/api/accounts/{account_id}/toggle")
def toggle_account(account_id: int, db: Session = Depends(get_db)):
    acc = db.get(models.SellerAccount, account_id)
    if not acc:
        raise HTTPException(404, "Account not found")
    acc.is_active = not acc.is_active
    db.commit()
    return {"id": acc.id, "is_active": acc.is_active}

@app.post("/api/orders/sync")
def sync_orders(account_id: int, days: int = 7, db: Session = Depends(get_db)):
    acc = db.get(models.SellerAccount, account_id)
    if not acc:
        raise HTTPException(404, "Account not found")
    cfg = {
        "region": acc.region,
        "refresh_token": acc.refresh_token,
        "lwa_client_id": acc.lwa_client_id or settings.LWA_CLIENT_ID,
        "lwa_client_secret": acc.lwa_client_secret or settings.LWA_CLIENT_SECRET,
        "aws_access_key": acc.aws_access_key or settings.AWS_ACCESS_KEY,
        "aws_secret_key": acc.aws_secret_key or settings.AWS_SECRET_KEY,
        "role_arn": acc.role_arn or settings.ROLE_ARN,
    }
    date_to = datetime.utcnow()
    date_from = date_to - timedelta(days=days)
    orders = pull_orders_stub(cfg, date_from, date_to)
    for o in orders:
        db.add(models.Order(
            account_id=acc.id,
            order_id=o["orderId"],
            purchase_date=datetime.fromisoformat(o["purchaseDate"]),
            status=o.get("status"),
            marketplace=o.get("marketplace"),
            data=o,
        ))
        for it in o.get("items", []):
            db.add(models.OrderItem(
                account_id=acc.id, order_id=o["orderId"],
                asin=it.get("asin"), sku=it.get("sku"),
                qty=it.get("qty"), price_amount=it.get("price"),
                currency=it.get("currency"),
            ))
    db.commit()
    return {"synced": len(orders)}

@app.post("/api/reports/pull")
def pull_reports(account_id: int, db: Session = Depends(get_db)):
    acc = db.get(models.SellerAccount, account_id)
    if not acc:
        raise HTTPException(404, "Account not found")
    cfg = {
        "region": acc.region,
        "refresh_token": acc.refresh_token,
    }
    stats = fetch_reports_and_upsert_stub(cfg)
    return {"status": "ok", "stats": stats}

@app.post("/api/recon/run")
def run_recon(account_id: int, days: int = 180, db: Session = Depends(get_db)):
    date_to = datetime.utcnow()
    date_from = date_to - timedelta(days=days)
    count = reconcile_account(db, account_id, date_from, date_to)
    return {"inserted": count}

@app.get("/api/recon/open")
def open_issues(account_id: int, db: Session = Depends(get_db)):
    rows = db.query(models.ReconResult).filter(
        models.ReconResult.account_id == account_id,
        models.ReconResult.open_units > 0
    ).order_by(models.ReconResult.open_units.desc()).limit(200).all()
    return [
        {
            "asin": r.asin, "sku": r.sku, "open_units": r.open_units,
            "lost": r.lost_units, "damaged": r.damaged_units, "found": r.found_units,
            "reimbursed": r.reimbursed_units
        } for r in rows
    ]
